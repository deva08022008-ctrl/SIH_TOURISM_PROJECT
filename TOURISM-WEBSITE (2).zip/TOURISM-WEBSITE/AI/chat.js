const params =
    new URLSearchParams(
        window.location.search
    );

const chatId =
    params.get("id");

const messages =
    document.getElementById(
        "messages"
    );


async function loadMessages() {

    const response =
        await fetch(
            `/api/chat/${chatId}/messages`
        );

    const data =
        await response.json();

    messages.innerHTML = "";

    data.forEach(message => {

        addMessage(
            message.role,
            message.content
        );

    });
}


function addMessage(role, content) {

    const div =
        document.createElement("div");

    div.className =
        role === "user"
            ? "message user"
            : "message ai";

    div.innerText = content;

    messages.appendChild(div);

    messages.scrollTop =
        messages.scrollHeight;
}


async function sendMessage() {

    const input =
        document.getElementById(
            "messageInput"
        );

    const text =
        input.value.trim();

    if (!text) return;

    addMessage(
        "user",
        text
    );

    input.value = "";

    const response =
        await fetch(
            `/api/chat/${chatId}/message`,
            {

                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify({
                    message: text
                })
            }
        );

    if (!response.ok) {

        addMessage(
            "assistant",
            "Sorry, something went wrong."
        );

        return;
    }

    const data =
        await response.json();

    addMessage(
        "assistant",
        data.response
    );
}


function goDashboard() {

    window.location.href =
        "dashboard.html";
}


document
    .getElementById("messageInput")
    .addEventListener(
        "keydown",
        function(event) {

            if (event.key === "Enter") {

                sendMessage();

            }

        }
    );


loadMessages();