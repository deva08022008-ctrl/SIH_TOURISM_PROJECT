package com.example.aichatbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiChatbotApplication {

    public static void main(String[] args) {

        SpringApplication.run(AiChatbotApplication.class, args);

        System.out.println("-----------------------------------");
        System.out.println("       AI CHATBOT STARTED");
        System.out.println("-----------------------------------");
        System.out.println("Open: http://localhost:8080");
    }
}