package com.example.aichatbot.controller;

import com.example.aichatbot.entity.ChatMessage;
import com.example.aichatbot.service.ChatService;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ChatController {

    private final ChatService chatService;

    public ChatController(ChatService chatService) {

        this.chatService = chatService;
    }

    @PostMapping("/chat")
    public Map<String, String> chat(
            @RequestBody Map<String, String> request) {

        String message = request.get("message");

        if (message == null || message.trim().isEmpty()) {

            return Map.of(
                    "error",
                    "Message cannot be empty"
            );
        }

        String response =
                chatService.askAI(message);

        return Map.of(
                "response",
                response
        );
    }

    @GetMapping("/history")
    public List<ChatMessage> getHistory() {

        return chatService.getChatHistory();
    }

    @DeleteMapping("/history")
    public Map<String, String> clearHistory() {

        chatService.clearHistory();

        return Map.of(
                "message",
                "Chat history deleted"
        );
    }
}