package com.example.aichatbot.controller;

import com.example.aichatbot.model.User;
import com.example.aichatbot.service.AuthService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public User register(@RequestBody Map<String, String> request) {

        String email = request.get("email");
        String password = request.get("password");

        User user =
                authService.register(email, password);

        user.setPassword(null);

        return user;
    }

    @PostMapping("/login")
    public User login(@RequestBody Map<String, String> request) {

        String email = request.get("email");
        String password = request.get("password");

        User user =
                authService.login(email, password);

        user.setPassword(null);

        return user;
    }
}