import com.openai.client.OpenAIClient;
import com.openai.client.okhttp.OpenAIOkHttpClient;
import com.openai.models.responses.Response;
import com.openai.models.responses.ResponseCreateParams;

import java.util.Scanner;

public class AIChatbot {

    public static void main(String[] args) {

        // Create OpenAI client
        OpenAIClient client = OpenAIOkHttpClient.fromEnv();

        Scanner scanner = new Scanner(System.in);

        System.out.println("=================================");
        System.out.println("        AI CHATBOT");
        System.out.println("=================================");
        System.out.println("Type 'exit' to stop the chatbot.");
        System.out.println();

        while (true) {

            System.out.print("You: ");
            String userInput = scanner.nextLine();

            // Exit condition
            if (userInput.equalsIgnoreCase("exit")) {
                System.out.println("Bot: Goodbye!");
                break;
            }

            try {

                // Create request
                ResponseCreateParams params =
                        ResponseCreateParams.builder()
                                .model("gpt-5.6")
                                .input(userInput)
                                .build();

                // Send request to AI
                Response response =
                        client.responses().create(params);

                // Get AI response
                StringBuilder answer = new StringBuilder();

                response.output()
                        .stream()
                        .flatMap(item -> item.message().stream())
                        .flatMap(message -> message.content().stream())
                        .flatMap(content -> content.outputText().stream())
                        .forEach(outputText ->
                                answer.append(outputText.text())
                        );

                System.out.println("Bot: " + answer);
                System.out.println();

            } catch (Exception e) {

                System.out.println(
                        "Bot: Sorry, something went wrong."
                );

                System.out.println(
                        "Error: " + e.getMessage()
                );
            }
        }

        scanner.close();
    }
}