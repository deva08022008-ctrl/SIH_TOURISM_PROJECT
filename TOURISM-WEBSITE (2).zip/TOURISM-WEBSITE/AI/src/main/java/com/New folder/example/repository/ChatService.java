package com.example.aichatbot.service;

import com.example.aichatbot.model.Chat;
import com.example.aichatbot.model.Message;
import com.example.aichatbot.model.User;
import com.example.aichatbot.repository.ChatRepository;
import com.example.aichatbot.repository.MessageRepository;
import com.example.aichatbot.repository.UserRepository;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChatService {

    private final ChatRepository chatRepository;
    private final MessageRepository messageRepository;
    private final UserRepository userRepository;
    private final OpenAIService openAIService;

    public ChatService(
            ChatRepository chatRepository,
            MessageRepository messageRepository,
            UserRepository userRepository,
            OpenAIService openAIService) {

        this.chatRepository = chatRepository;
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
        this.openAIService = openAIService;
    }

    public Chat createChat(Long userId, String title) {

        User user =
                userRepository.findById(userId)
                        .orElseThrow();

        Chat chat =
                new Chat(title, user);

        return chatRepository.save(chat);
    }

    public List<Chat> getChats(Long userId) {

        User user =
                userRepository.findById(userId)
                        .orElseThrow();

        return chatRepository
                .findByUserOrderByCreatedAtDesc(user);
    }

    public List<Message> getMessages(Long chatId) {

        Chat chat =
                chatRepository.findById(chatId)
                        .orElseThrow();

        return messageRepository
                .findByChatOrderByCreatedAtAsc(chat);
    }

    public String sendMessage(
            Long chatId,
            String userMessage) {

        Chat chat =
                chatRepository.findById(chatId)
                        .orElseThrow();

        Message userMsg =
                new Message(
                        userMessage,
                        "user",
                        chat
                );

        messageRepository.save(userMsg);

        String aiResponse =
                openAIService.askAI(userMessage);

        Message aiMsg =
                new Message(
                        aiResponse,
                        "assistant",
                        chat
                );

        messageRepository.save(aiMsg);

        return aiResponse;
    }

    public void renameChat(
            Long chatId,
            String title) {

        Chat chat =
                chatRepository.findById(chatId)
                        .orElseThrow();

        chat.setTitle(title);

        chatRepository.save(chat);
    }

    public void deleteChat(Long chatId) {

        chatRepository.deleteById(chatId);
    }
}