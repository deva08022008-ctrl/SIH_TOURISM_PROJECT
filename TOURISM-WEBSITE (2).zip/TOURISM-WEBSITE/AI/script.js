async function login() {

    const email =
        document.getElementById("email").value;

    const password =
        document.getElementById("password").value;

    const response =
        await fetch("/api/auth/login", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                email: email,
                password: password
            })
        });

    if (!response.ok) {

        document.getElementById("message")
            .innerText =
            "Invalid email or password";

        return;
    }

    const user =
        await response.json();

    localStorage.setItem(
        "userId",
        user.id
    );

    localStorage.setItem(
        "userEmail",
        user.email
    );

    window.location.href =
        "dashboard.html";
}


async function register() {

    const email =
        document.getElementById("email").value;

    const password =
        document.getElementById("password").value;

    if (!email || !password) {

        document.getElementById("message")
            .innerText =
            "Enter email and password";

        return;
    }

    const response =
        await fetch("/api/auth/register", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                email: email,
                password: password
            })
        });

    if (response.ok) {

        document.getElementById("message")
            .innerText =
            "Registration successful. Now login.";

    } else {

        document.getElementById("message")
            .innerText =
            "Registration failed.";
    }
}