const userId =
    localStorage.getItem("userId");

const userEmail =
    localStorage.getItem("userEmail");

if (!userId) {

    window.location.href =
        "index.html";
}

document.getElementById("welcome")
    .innerText =
    "Logged in as " + userEmail;


async function loadChats() {

    const response =
        await fetch(
            `/api/chat/list/${userId}`
        );

    const chats =
        await response.json();

    const list =
        document.getElementById(
            "chatList"
        );

    list.innerHTML = "";

    chats.forEach(chat => {

        const div =
            document.createElement("div");

        div.className =
            "chat-item";

        div.innerHTML = `

            <span onclick="openChat(${chat.id})">
                ${chat.title}
            </span>

            <button onclick="renameChat(${chat.id})">
                ✏
            </button>

            <button onclick="deleteChat(${chat.id})">
                🗑
            </button>

        `;

        list.appendChild(div);

    });
}


async function newChat() {

    const response =
        await fetch("/api/chat/new", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({

                userId: userId,

                title: "New Chat"

            })
        });

    const chat =
        await response.json();

    window.location.href =
        `chat.html?id=${chat.id}`;
}


function openChat(id) {

    window.location.href =
        `chat.html?id=${id}`;
}


async function renameChat(id) {

    const title =
        prompt("Enter new chat name:");

    if (!title) return;

    await fetch(
        `/api/chat/${id}/rename`,
        {

            method: "PUT",

            headers: {
                "Content-Type":
                    "application/json"
            },

            body: JSON.stringify({
                title: title
            })
        }
    );

    loadChats();
}


async function deleteChat(id) {

    if (!confirm(
        "Delete this conversation?"
    )) {
        return;
    }

    await fetch(
        `/api/chat/${id}`,
        {
            method: "DELETE"
        }
    );

    loadChats();
}


function logout() {

    localStorage.clear();

    window.location.href =
        "index.html";
}


loadChats();