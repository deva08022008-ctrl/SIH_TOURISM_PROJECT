# Tourism API — Spring Boot

## Stack
Java 21, Spring Boot 3.5, Spring Security + JWT, JPA/Hibernate, PostgreSQL, Flyway, OpenAPI/Swagger, Actuator.

## Run
1. Install Java 21 and Maven.
2. Start PostgreSQL:
   `docker compose up -d`
3. Copy `.env.example` values into your environment.
4. Change `JWT_SECRET` to a strong random secret in production.
5. Run:
   `mvn spring-boot:run`
6. Swagger:
   `http://localhost:8080/swagger-ui.html`

## Frontend
Put the tourism frontend files in:
`src/main/resources/static/`
- `index.html`
- `css/style.css`
- `js/script.js`

The supplied frontend calls:
- `GET /api/destinations`
- `POST /api/auth/login`
- `POST /api/bookings`

## Main endpoints

### Authentication
- `POST /api/auth/register` — 201
- `POST /api/auth/login` — 200

### Destinations
- `GET /api/destinations?q=&category=&minPrice=&maxPrice=&available=` — 200
- `GET /api/destinations/{id}` — 200/404
- `POST /api/destinations` — ADMIN, 201
- `PUT /api/destinations/{id}` — ADMIN, 200
- `DELETE /api/destinations/{id}` — ADMIN, 204

### Bookings
- `POST /api/bookings` — authenticated, 201
- `GET /api/bookings/mine` — authenticated
- `GET /api/bookings/{id}` — authenticated
- `PATCH /api/bookings/{id}/cancel` — authenticated

### Payments
- `POST /api/payments` — authenticated
Payment providers are modeled for Stripe/Razorpay/PayPal. The `MOCK` provider confirms immediately. Replace `PaymentService` with your provider SDK and webhook verification before production payments.

### Itineraries
- `POST /api/itineraries`
- `GET /api/itineraries/mine`

### Reviews
- `POST /api/reviews`

### Admin
- `GET /api/admin/users`
- `GET /api/admin/bookings`

## Security
- BCrypt password hashing
- Stateless JWT authentication
- Role-based authorization
- CORS allowlist
- In-memory per-IP rate limiting
- Validation and centralized error responses
- Request logging
- Actuator health/metrics

## Production notes
The included rate limiter is intentionally dependency-free and single-instance. For multiple application instances, replace it with Redis/Bucket4j or an API gateway. Add HTTPS, secret management, provider webhooks, email/SMS notification provider, audit logs, and database backups before production launch.
