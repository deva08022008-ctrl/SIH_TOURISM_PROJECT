CREATE TABLE users (
 id BIGSERIAL PRIMARY KEY,
 email VARCHAR(180) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 full_name VARCHAR(120) NOT NULL,
 role VARCHAR(30) NOT NULL,
 enabled BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE destinations (
 id BIGSERIAL PRIMARY KEY,
 name VARCHAR(180) NOT NULL,
 city VARCHAR(120) NOT NULL,
 country VARCHAR(120) NOT NULL,
 category VARCHAR(60) NOT NULL,
 description TEXT NOT NULL,
 price NUMERIC(12,2),
 available BOOLEAN NOT NULL DEFAULT TRUE,
 latitude DOUBLE PRECISION,
 longitude DOUBLE PRECISION,
 image_url VARCHAR(1000)
);

CREATE TABLE reviews (
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES users(id),
 destination_id BIGINT NOT NULL REFERENCES destinations(id) ON DELETE CASCADE,
 rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
 comment TEXT,
 created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE bookings (
 id BIGSERIAL PRIMARY KEY,
 booking_reference VARCHAR(40) NOT NULL UNIQUE,
 user_id BIGINT NOT NULL REFERENCES users(id),
 destination_id BIGINT NOT NULL REFERENCES destinations(id),
 booking_date DATE NOT NULL,
 guests INTEGER NOT NULL CHECK (guests > 0),
 total_amount NUMERIC(12,2) NOT NULL,
 status VARCHAR(30) NOT NULL,
 notes VARCHAR(1000),
 created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE payments (
 id BIGSERIAL PRIMARY KEY,
 booking_id BIGINT NOT NULL UNIQUE REFERENCES bookings(id),
 provider VARCHAR(30) NOT NULL,
 status VARCHAR(30) NOT NULL,
 amount NUMERIC(12,2) NOT NULL,
 provider_payment_id VARCHAR(255),
 created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE itineraries (
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title VARCHAR(160) NOT NULL,
 description TEXT,
 created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE itinerary_items (
 id BIGSERIAL PRIMARY KEY,
 itinerary_id BIGINT NOT NULL REFERENCES itineraries(id) ON DELETE CASCADE,
 day_number INTEGER NOT NULL CHECK (day_number > 0),
 start_time TIME,
 end_time TIME,
 title VARCHAR(180) NOT NULL,
 notes TEXT
);

CREATE INDEX idx_destinations_location ON destinations(city,country);
CREATE INDEX idx_destinations_category ON destinations(category);
CREATE INDEX idx_destinations_price ON destinations(price);
CREATE INDEX idx_bookings_date ON bookings(destination_id,booking_date,status);
CREATE INDEX idx_reviews_destination ON reviews(destination_id);
