package com.tourism.api.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public final class DestinationDtos {
    private DestinationDtos(){}

    public record CreateRequest(
        @NotBlank String name, @NotBlank String city, @NotBlank String country,
        @NotBlank String category, @NotBlank String description,
        @PositiveOrZero BigDecimal price, Boolean available,
        @DecimalMin("-90") @DecimalMax("90") Double latitude,
        @DecimalMin("-180") @DecimalMax("180") Double longitude,
        String imageUrl
    ) {}

    public record Response(
        Long id, String name, String city, String country, String category,
        String description, BigDecimal price, boolean available,
        Double latitude, Double longitude, String imageUrl, Double rating
    ) {}
}
