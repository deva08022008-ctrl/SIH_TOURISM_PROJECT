package com.tourism.api.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.math.BigDecimal;

public final class BookingDtos {
    private BookingDtos(){}

    public record CreateRequest(
        @NotNull Long destinationId,
        @NotNull @FutureOrPresent LocalDate bookingDate,
        @NotNull @Min(1) @Max(100) Integer guests,
        @Size(max=1000) String notes
    ) {}

    public record Response(
        Long id, String bookingReference, Long destinationId, String destinationName,
        LocalDate bookingDate, Integer guests, BigDecimal totalAmount, String status
    ) {}
}
