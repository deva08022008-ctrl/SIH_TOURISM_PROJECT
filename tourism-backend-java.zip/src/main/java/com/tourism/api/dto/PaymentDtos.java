package com.tourism.api.dto;
import com.tourism.api.model.PaymentProvider;
import jakarta.validation.constraints.*;

public final class PaymentDtos {
    private PaymentDtos(){}
    public record CreateRequest(@NotNull Long bookingId, @NotNull PaymentProvider provider) {}
}
