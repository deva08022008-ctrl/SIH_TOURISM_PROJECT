package com.tourism.api.dto;

import com.tourism.api.model.Role;
import jakarta.validation.constraints.*;

public final class AuthDtos {
    private AuthDtos(){}

    public record RegisterRequest(
        @NotBlank @Size(max=120) String fullName,
        @NotBlank @Email @Size(max=180) String email,
        @NotBlank @Size(min=8, max=100) String password,
        Role role
    ) {}

    public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) {}

    public record AuthResponse(String token, Long userId, String email, String fullName, Role role) {}
}
