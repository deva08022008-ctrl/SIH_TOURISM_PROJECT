package com.tourism.api.dto;
public final class NotificationDtos {
    private NotificationDtos(){}
    public record Response(Long id,String title,String message,boolean read,String createdAt){}
}