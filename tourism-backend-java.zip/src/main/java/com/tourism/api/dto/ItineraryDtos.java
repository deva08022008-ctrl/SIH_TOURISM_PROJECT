package com.tourism.api.dto;

import jakarta.validation.constraints.*;
import java.time.LocalTime;
import java.util.List;

public final class ItineraryDtos {
    private ItineraryDtos(){}
    public record ItemRequest(@Min(1) int dayNumber, LocalTime startTime, LocalTime endTime, @NotBlank String title, String notes) {}
    public record CreateRequest(@NotBlank String title, String description, List<@Valid ItemRequest> items) {}
}
