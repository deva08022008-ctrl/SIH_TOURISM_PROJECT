package com.tourism.api.dto;
import jakarta.validation.constraints.*;

public final class ReviewDtos {
    private ReviewDtos(){}
    public record CreateRequest(@NotNull Long destinationId, @NotNull @Min(1) @Max(5) Integer rating, @Size(max=2000) String comment) {}
}
