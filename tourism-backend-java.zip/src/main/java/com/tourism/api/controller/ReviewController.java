package com.tourism.api.controller;
import com.tourism.api.dto.ReviewDtos.CreateRequest;
import com.tourism.api.service.ReviewService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/reviews")
public class ReviewController {
 private final ReviewService service; public ReviewController(ReviewService s){service=s;}
 @PostMapping ResponseEntity<Void> create(@Valid @RequestBody CreateRequest r,java.security.Principal p){service.create(r,p.getName());return ResponseEntity.status(HttpStatus.CREATED).build();}
}
