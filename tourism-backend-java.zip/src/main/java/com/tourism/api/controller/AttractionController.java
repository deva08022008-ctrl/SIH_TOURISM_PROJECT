package com.tourism.api.controller;
import com.tourism.api.model.Attraction;
import com.tourism.api.repository.AttractionRepository;
import com.tourism.api.exception.ApiException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/attractions") @RequiredArgsConstructor
public class AttractionController {
    private final AttractionRepository repo;
    @GetMapping("/{id}") Attraction get(@PathVariable Long id){return repo.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Attraction not found"));}
    @GetMapping("/destination/{destinationId}") List<Attraction> byDestination(@PathVariable Long destinationId){return repo.findByDestinationId(destinationId);}
}
