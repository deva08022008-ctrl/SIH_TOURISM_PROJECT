package com.tourism.api.controller;

import com.tourism.api.model.Role;
import com.tourism.api.repository.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.List;

@RestController @RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {
    private final UserRepository users;
    private final BookingRepository bookings;
    public AdminController(UserRepository u, BookingRepository b){users=u;bookings=b;}

    @GetMapping("/users")
    List<UserSummary> users(){
        return users.findAll().stream()
            .map(u -> new UserSummary(u.getId(),u.getEmail(),u.getFullName(),u.getRole(),u.isEnabled(),u.getCreatedAt()))
            .toList();
    }

    @GetMapping("/bookings")
    List<?> bookings(){ return bookings.findAll(); }

    record UserSummary(Long id,String email,String fullName,Role role,boolean enabled,Instant createdAt){}
}
