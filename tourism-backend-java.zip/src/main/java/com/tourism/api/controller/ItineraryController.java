package com.tourism.api.controller;
import com.tourism.api.dto.ItineraryDtos.CreateRequest;
import com.tourism.api.model.Itinerary;
import com.tourism.api.service.ItineraryService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/itineraries")
public class ItineraryController {
 private final ItineraryService service; public ItineraryController(ItineraryService s){service=s;}
 @PostMapping ResponseEntity<Itinerary> create(@Valid @RequestBody CreateRequest r,java.security.Principal p){return ResponseEntity.status(HttpStatus.CREATED).body(service.create(r,p.getName()));}
 @GetMapping("/mine") java.util.List<Itinerary> mine(java.security.Principal p){return service.mine(p.getName());}
}
