package com.tourism.api.controller;
import com.tourism.api.dto.NotificationDtos;
import com.tourism.api.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/notifications") @RequiredArgsConstructor
public class NotificationController {
    private final NotificationService service; private final CurrentUserService current;
    @GetMapping List<NotificationDtos.Response> mine(){return service.mine(current.get());}
}
