package com.tourism.api.controller;
import com.tourism.api.dto.PaymentDtos.CreateRequest;
import com.tourism.api.model.Payment;
import com.tourism.api.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/payments")
public class PaymentController {
 private final PaymentService service; public PaymentController(PaymentService s){service=s;}
 @PostMapping ResponseEntity<Payment> create(@Valid @RequestBody CreateRequest r,java.security.Principal p){return ResponseEntity.status(HttpStatus.CREATED).body(service.create(r,p.getName()));}
}
