package com.tourism.api.controller;
import com.tourism.api.dto.DestinationDtos.*;
import com.tourism.api.service.DestinationService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
@RestController @RequestMapping("/api/destinations")
public class DestinationController {
 private final DestinationService service; public DestinationController(DestinationService s){service=s;}
 @GetMapping ResponseEntity<?> search(@RequestParam(required=false) String q,@RequestParam(required=false) String category,
   @RequestParam(required=false) BigDecimal minPrice,@RequestParam(required=false) BigDecimal maxPrice,@RequestParam(required=false) Boolean available){
   return ResponseEntity.ok(service.search(q,category,minPrice,maxPrice,available));
 }
 @GetMapping("/{id}") ResponseEntity<Response> get(@PathVariable Long id){return ResponseEntity.ok(service.get(id));}
 @PreAuthorize("hasRole('ADMIN')") @PostMapping ResponseEntity<Response> create(@Valid @RequestBody CreateRequest r){return ResponseEntity.status(HttpStatus.CREATED).body(service.create(r));}
 @PreAuthorize("hasRole('ADMIN')") @PutMapping("/{id}") ResponseEntity<Response> update(@PathVariable Long id,@Valid @RequestBody CreateRequest r){return ResponseEntity.ok(service.update(id,r));}
 @PreAuthorize("hasRole('ADMIN')") @DeleteMapping("/{id}") ResponseEntity<Void> delete(@PathVariable Long id){service.delete(id);return ResponseEntity.noContent().build();}
}
