package com.tourism.api.controller;
import com.tourism.api.dto.BookingDtos.*;
import com.tourism.api.service.BookingService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/bookings")
public class BookingController {
 private final BookingService service; public BookingController(BookingService s){service=s;}
 @PostMapping ResponseEntity<Response> create(@Valid @RequestBody CreateRequest r,java.security.Principal p){return ResponseEntity.status(HttpStatus.CREATED).body(service.create(r,p.getName()));}
 @GetMapping("/mine") java.util.List<Response> mine(java.security.Principal p){return service.mine(p.getName());}
 @GetMapping("/{id}") Response<Response> get(@PathVariable Long id,java.security.Principal p){return Response.ok(service.get(id,p.getName()));}
 @PatchMapping("/{id}/cancel") Response<Response> cancel(@PathVariable Long id,java.security.Principal p){return Response.ok(service.cancel(id,p.getName()));}
}
