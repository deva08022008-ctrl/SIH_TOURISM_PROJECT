package com.tourism.api.repository;

import com.tourism.api.model.Attraction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AttractionRepository extends JpaRepository<Attraction, Long> {
    java.util.List<Attraction> findByDestinationId(Long destinationId);
}
