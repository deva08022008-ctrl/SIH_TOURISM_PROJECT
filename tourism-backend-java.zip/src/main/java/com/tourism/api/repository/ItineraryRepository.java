package com.tourism.api.repository;
import com.tourism.api.model.Itinerary;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ItineraryRepository extends JpaRepository<Itinerary,Long>{ List<Itinerary> findByUserIdOrderByCreatedAtDesc(Long userId); }