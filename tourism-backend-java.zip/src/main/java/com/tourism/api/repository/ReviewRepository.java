package com.tourism.api.repository;
import com.tourism.api.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
public interface ReviewRepository extends JpaRepository<Review,Long>{
 @Query("select coalesce(avg(r.rating),0) from Review r where r.destination.id=:destinationId") Double averageRating(Long destinationId);
}