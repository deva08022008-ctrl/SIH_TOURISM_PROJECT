package com.tourism.api.repository;
import com.tourism.api.model.Destination;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;
public interface DestinationRepository extends JpaRepository<Destination,Long>{
 @Query("select d from Destination d where (:q is null or lower(d.name) like lower(concat('%',:q,'%')) or lower(d.city) like lower(concat('%',:q,'%')) or lower(d.country) like lower(concat('%',:q,'%'))) and (:category is null or lower(d.category)=lower(:category)) and (:minPrice is null or d.price>=:minPrice) and (:maxPrice is null or d.price<=:maxPrice) and (:available is null or d.available=:available)")
 List<Destination> search(@Param("q") String q,@Param("category") String category,@Param("minPrice") java.math.BigDecimal minPrice,@Param("maxPrice") java.math.BigDecimal maxPrice,@Param("available") Boolean available);
}