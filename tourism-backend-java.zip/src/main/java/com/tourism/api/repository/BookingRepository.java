package com.tourism.api.repository;
import com.tourism.api.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.*;
public interface BookingRepository extends JpaRepository<Booking,Long>{
 Optional<Booking> findByBookingReference(String ref);
 List<Booking> findByUserIdOrderByCreatedAtDesc(Long userId);
 long countByDestinationIdAndBookingDateAndStatusIn(Long destinationId, LocalDate date, Collection<com.tourism.api.model.BookingStatus> statuses);
}