package com.tourism.api.service;

import com.tourism.api.dto.AuthDtos.*;
import com.tourism.api.exception.ApiException;
import com.tourism.api.model.*;
import com.tourism.api.repository.UserRepository;
import com.tourism.api.security.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final UserRepository users; private final PasswordEncoder encoder; private final AuthenticationManager auth; private final JwtService jwt;
    public AuthService(UserRepository u,PasswordEncoder e,AuthenticationManager a,JwtService j){users=u;encoder=e;auth=a;jwt=j;}
    public AuthResponse register(RegisterRequest r){
        if(users.existsByEmailIgnoreCase(r.email())) throw new ApiException(HttpStatus.CONFLICT,"Email already registered");
        Role role=r.role()==null?Role.TOURIST:r.role();
        if(role==Role.ADMIN) throw new ApiException(HttpStatus.FORBIDDEN,"Admin accounts cannot be self-registered");
        User u=users.save(User.builder().fullName(r.fullName().trim()).email(r.email().toLowerCase().trim()).passwordHash(encoder.encode(r.password())).role(role).enabled(true).build());
        var principal=org.springframework.security.core.userdetails.User.withUsername(u.getEmail()).password(u.getPasswordHash()).roles(u.getRole().name()).build();
        return new AuthResponse(jwt.generate(principal),u.getId(),u.getEmail(),u.getFullName(),u.getRole());
    }
    public AuthResponse login(LoginRequest r){
        try{auth.authenticate(new UsernamePasswordAuthenticationToken(r.email(),r.password()));}
        catch(AuthenticationException e){throw new ApiException(HttpStatus.UNAUTHORIZED,"Invalid email or password");}
        User u=users.findByEmailIgnoreCase(r.email()).orElseThrow();
        var principal=org.springframework.security.core.userdetails.User.withUsername(u.getEmail()).password(u.getPasswordHash()).roles(u.getRole().name()).build();
        return new AuthResponse(jwt.generate(principal),u.getId(),u.getEmail(),u.getFullName(),u.getRole());
    }
}
