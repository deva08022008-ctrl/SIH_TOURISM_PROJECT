package com.tourism.api.service;
import com.tourism.api.dto.PaymentDtos.CreateRequest;
import com.tourism.api.exception.ApiException;
import com.tourism.api.model.*;
import com.tourism.api.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.UUID;
@Service
public class PaymentService {
 private final PaymentRepository payments; private final BookingRepository bookings;
 public PaymentService(PaymentRepository p,BookingRepository b){payments=p;bookings=b;}
 public Payment create(CreateRequest r,String email){
   Booking b=bookings.findById(r.bookingId()).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Booking not found"));
   if(!b.getUser().getEmail().equalsIgnoreCase(email))throw new ApiException(HttpStatus.FORBIDDEN,"Access denied");
   if(payments.findByBookingId(b.getId()).isPresent())throw new ApiException(HttpStatus.CONFLICT,"Payment already exists");
   // Replace this MOCK block with Stripe/Razorpay SDK code and webhook verification in production.
   Payment p=Payment.builder().booking(b).provider(r.provider()).status(r.provider()==PaymentProvider.MOCK?PaymentStatus.PAID:PaymentStatus.PENDING)
      .amount(b.getTotalAmount()).providerPaymentId("PAY-"+UUID.randomUUID()).build();
   Payment saved=payments.save(p);
   if(saved.getStatus()==PaymentStatus.PAID){b.setStatus(BookingStatus.CONFIRMED);bookings.save(b);}
   return saved;
 }
}
