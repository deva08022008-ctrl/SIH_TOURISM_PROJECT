package com.tourism.api.service;
import com.tourism.api.dto.NotificationDtos;
import com.tourism.api.model.*;
import com.tourism.api.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.*;
@Service @RequiredArgsConstructor
public class NotificationService {
    private final NotificationRepository repo;
    public void send(User u,String title,String message){repo.save(Notification.builder().user(u).title(title).message(message).readFlag(false).build());}
    public List<NotificationDtos.Response> mine(User u){return repo.findByUserIdOrderByCreatedAtDesc(u.getId()).stream().map(n->new NotificationDtos.Response(n.getId(),n.getTitle(),n.getMessage(),n.isReadFlag(),n.getCreatedAt().toString())).toList();}
}
