package com.tourism.api.service;
import com.tourism.api.dto.ReviewDtos.CreateRequest;
import com.tourism.api.exception.ApiException;
import com.tourism.api.model.*;
import com.tourism.api.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
@Service
public class ReviewService {
 private final ReviewRepository reviews; private final DestinationRepository destinations; private final UserRepository users;
 public ReviewService(ReviewRepository r,DestinationRepository d,UserRepository u){reviews=r;destinations=d;users=u;}
 public void create(CreateRequest r,String email){
   User u=users.findByEmailIgnoreCase(email).orElseThrow();
   Destination d=destinations.findById(r.destinationId()).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Destination not found"));
   reviews.save(Review.builder().user(u).destination(d).rating(r.rating()).comment(r.comment()).build());
 }
}
