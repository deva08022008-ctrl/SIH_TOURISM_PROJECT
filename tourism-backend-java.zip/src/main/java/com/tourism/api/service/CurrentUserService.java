package com.tourism.api.service;
import com.tourism.api.model.User;
import com.tourism.api.repository.UserRepository;
import com.tourism.api.exception.ApiException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class CurrentUserService {
    private final UserRepository users;
    public User get() {
        Object p=SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if(!(p instanceof String email)) throw new ApiException(HttpStatus.UNAUTHORIZED,"Authentication required");
        User u=users.findByEmailIgnoreCase(email);
        if(u==null) throw new ApiException(HttpStatus.UNAUTHORIZED,"User not found");
        return u;
    }
}
