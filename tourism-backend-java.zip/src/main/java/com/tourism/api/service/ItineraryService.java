package com.tourism.api.service;
import com.tourism.api.dto.ItineraryDtos.*;
import com.tourism.api.model.*;
import com.tourism.api.repository.*;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class ItineraryService {
 private final ItineraryRepository itineraries; private final UserRepository users;
 public ItineraryService(ItineraryRepository i,UserRepository u){itineraries=i;users=u;}
 public Itinerary create(CreateRequest r,String email){
   User u=users.findByEmailIgnoreCase(email).orElseThrow();
   Itinerary it=Itinerary.builder().user(u).title(r.title()).description(r.description()).build();
   if(r.items()!=null) for(ItemRequest x:r.items()) it.getItems().add(ItineraryItem.builder().itinerary(it).dayNumber(x.dayNumber()).startTime(x.startTime()).endTime(x.endTime()).title(x.title()).notes(x.notes()).build());
   return itineraries.save(it);
 }
 public List<Itinerary> mine(String email){return itineraries.findByUserIdOrderByCreatedAtDesc(users.findByEmailIgnoreCase(email).orElseThrow().getId());}
}
