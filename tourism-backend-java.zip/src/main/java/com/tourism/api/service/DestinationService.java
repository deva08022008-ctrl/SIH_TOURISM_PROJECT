package com.tourism.api.service;

import com.tourism.api.dto.DestinationDtos.*;
import com.tourism.api.exception.ApiException;
import com.tourism.api.model.Destination;
import com.tourism.api.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.*;

@Service
public class DestinationService {
    private final DestinationRepository destinations; private final ReviewRepository reviews;
    public DestinationService(DestinationRepository d,ReviewRepository r){destinations=d;reviews=r;}

    public List<Response> search(String q,String category,BigDecimal min,BigDecimal max,Boolean available){
        return destinations.search(q,category,min,max,available).stream().map(this::toResponse).toList();
    }
    public Response get(Long id){return toResponse(destinations.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Destination not found")));}
    public Response create(CreateRequest r){
        Destination d=Destination.builder().name(r.name()).city(r.city()).country(r.country()).category(r.category())
            .description(r.description()).price(r.price()).available(r.available()==null||r.available())
            .latitude(r.latitude()).longitude(r.longitude()).imageUrl(r.imageUrl()).build();
        return toResponse(destinations.save(d));
    }
    public Response update(Long id,CreateRequest r){
        Destination d=destinations.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Destination not found"));
        d.setName(r.name());d.setCity(r.city());d.setCountry(r.country());d.setCategory(r.category());d.setDescription(r.description());
        d.setPrice(r.price());d.setAvailable(r.available()==null||r.available());d.setLatitude(r.latitude());d.setLongitude(r.longitude());d.setImageUrl(r.imageUrl());
        return toResponse(destinations.save(d));
    }
    public void delete(Long id){if(!destinations.existsById(id))throw new ApiException(HttpStatus.NOT_FOUND,"Destination not found");destinations.deleteById(id);}
    private Response toResponse(Destination d){return new Response(d.getId(),d.getName(),d.getCity(),d.getCountry(),d.getCategory(),d.getDescription(),d.getPrice(),d.isAvailable(),d.getLatitude(),d.getLongitude(),d.getImageUrl(),reviews.averageRating(d.getId()));}
}
