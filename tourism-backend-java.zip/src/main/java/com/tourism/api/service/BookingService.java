package com.tourism.api.service;

import com.tourism.api.dto.BookingDtos.*;
import com.tourism.api.exception.ApiException;
import com.tourism.api.model.*;
import com.tourism.api.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class BookingService {
    private final BookingRepository bookings; private final DestinationRepository destinations; private final UserRepository users;
    public BookingService(BookingRepository b,DestinationRepository d,UserRepository u){bookings=b;destinations=d;users=u;}

    public Response create(CreateRequest r,String email){
        User u=users.findByEmailIgnoreCase(email).orElseThrow();
        Destination d=destinations.findById(r.destinationId()).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Destination not found"));
        if(!d.isAvailable())throw new ApiException(HttpStatus.CONFLICT,"Destination is not available");
        long reserved=bookings.countByDestinationIdAndBookingDateAndStatusIn(d.getId(),r.bookingDate(),List.of(BookingStatus.PENDING,BookingStatus.CONFIRMED));
        if(reserved+r.guests()>100)throw new ApiException(HttpStatus.CONFLICT,"Not enough availability for this date");
        BigDecimal unit=d.getPrice()==null?BigDecimal.ZERO:d.getPrice();
        Booking b=Booking.builder().bookingReference("TRV-"+System.currentTimeMillis()+"-"+ThreadLocalRandom.current().nextInt(100,999))
            .user(u).destination(d).bookingDate(r.bookingDate()).guests(r.guests()).totalAmount(unit.multiply(BigDecimal.valueOf(r.guests())))
            .status(BookingStatus.PENDING).notes(r.notes()).build();
        return toResponse(bookings.save(b));
    }
    public List<Response> mine(String email){User u=users.findByEmailIgnoreCase(email).orElseThrow();return bookings.findByUserIdOrderByCreatedAtDesc(u.getId()).stream().map(this::toResponse).toList();}
    public Response get(Long id,String email){
        Booking b=bookings.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Booking not found"));
        if(!b.getUser().getEmail().equalsIgnoreCase(email) && !isAdmin(email))throw new ApiException(HttpStatus.FORBIDDEN,"Access denied");
        return toResponse(b);
    }
    public Response cancel(Long id,String email){
        Booking b=bookings.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Booking not found"));
        if(!b.getUser().getEmail().equalsIgnoreCase(email) && !isAdmin(email))throw new ApiException(HttpStatus.FORBIDDEN,"Access denied");
        if(b.getStatus()==BookingStatus.COMPLETED)throw new ApiException(HttpStatus.CONFLICT,"Completed booking cannot be cancelled");
        b.setStatus(BookingStatus.CANCELLED);return toResponse(bookings.save(b));
    }
    private boolean isAdmin(String email){return users.findByEmailIgnoreCase(email).map(u->u.getRole()==Role.ADMIN).orElse(false);}
    private Response toResponse(Booking b){return new Response(b.getId(),b.getBookingReference(),b.getDestination().getId(),b.getDestination().getName(),b.getBookingDate(),b.getGuests(),b.getTotalAmount(),b.getStatus().name());}
}
