package com.tourism.api.model;
public enum PaymentStatus { PENDING, PAID, FAILED, REFUNDED }
