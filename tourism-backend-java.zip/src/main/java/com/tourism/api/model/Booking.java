package com.tourism.api.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.*;

@Entity @Table(name="bookings")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Booking {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false, unique=true, length=40) private String bookingReference;

    @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="user_id")
    private User user;
    @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="destination_id")
    private Destination destination;

    @Column(nullable=false) private LocalDate bookingDate;
    @Column(nullable=false) private Integer guests;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal totalAmount;
    @Enumerated(EnumType.STRING) @Column(nullable=false) private BookingStatus status;
    private String notes;
    @Column(nullable=false, updatable=false) private Instant createdAt;

    @PrePersist void prePersist(){ createdAt=Instant.now(); }
}
