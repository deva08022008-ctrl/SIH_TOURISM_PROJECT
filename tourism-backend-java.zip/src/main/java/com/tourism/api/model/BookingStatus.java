package com.tourism.api.model;
public enum BookingStatus { PENDING, CONFIRMED, CANCELLED, COMPLETED }
