package com.tourism.api.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity @Table(name="attractions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Attraction {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch=FetchType.LAZY, optional=false) private Destination destination;
    @Column(nullable=false, length=180) private String name;
    @Column(nullable=false, columnDefinition="text") private String description;
    @Enumerated(EnumType.STRING) private AttractionCategory category;
    @Column(nullable=false, precision=10, scale=2) private BigDecimal price;
    @Column(nullable=false) private boolean available = true;
    @Column(nullable=false) private String imageUrl;
    @Column(nullable=false, precision=10, scale=7) private BigDecimal latitude;
    @Column(nullable=false, precision=10, scale=7) private BigDecimal longitude;
}
