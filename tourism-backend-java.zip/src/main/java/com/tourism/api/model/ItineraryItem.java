package com.tourism.api.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalTime;

@Entity @Table(name="itinerary_items")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ItineraryItem {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="itinerary_id") private Itinerary itinerary;
    private int dayNumber;
    private LocalTime startTime;
    private LocalTime endTime;
    @Column(nullable=false, length=180) private String title;
    private String notes;
}
