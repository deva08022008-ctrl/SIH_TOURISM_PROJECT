package com.tourism.api.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity @Table(name="payments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Payment {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;

    @OneToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="booking_id", unique=true)
    private Booking booking;

    @Enumerated(EnumType.STRING) @Column(nullable=false) private PaymentProvider provider;
    @Enumerated(EnumType.STRING) @Column(nullable=false) private PaymentStatus status;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal amount;
    private String providerPaymentId;
    @Column(nullable=false, updatable=false) private Instant createdAt;

    @PrePersist void prePersist(){ createdAt=Instant.now(); }
}
