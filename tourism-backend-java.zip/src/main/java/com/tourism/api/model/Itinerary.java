package com.tourism.api.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;
import java.util.*;

@Entity @Table(name="itineraries")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Itinerary {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="user_id") private User user;
    @Column(nullable=false, length=160) private String title;
    private String description;
    @Column(nullable=false, updatable=false) private Instant createdAt;

    @OneToMany(mappedBy="itinerary", cascade=CascadeType.ALL, orphanRemoval=true)
    @OrderBy("dayNumber ASC, startTime ASC")
    @Builder.Default private List<ItineraryItem> items=new ArrayList<>();

    @PrePersist void prePersist(){ createdAt=Instant.now(); }
}
