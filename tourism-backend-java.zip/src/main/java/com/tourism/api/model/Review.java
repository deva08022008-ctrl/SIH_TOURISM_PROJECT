package com.tourism.api.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity @Table(name="reviews")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Review {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="user_id")
    private User user;

    @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="destination_id")
    private Destination destination;

    @Column(nullable=false) private Integer rating;
    @Column(columnDefinition="TEXT") private String comment;
    @Column(nullable=false, updatable=false) private Instant createdAt;

    @PrePersist void prePersist(){ createdAt=Instant.now(); }
}
