package com.tourism.api.model;
public enum AttractionCategory { BEACH, HERITAGE, NATURE, ADVENTURE, CULTURE, RELIGIOUS, CITY, OTHER }
