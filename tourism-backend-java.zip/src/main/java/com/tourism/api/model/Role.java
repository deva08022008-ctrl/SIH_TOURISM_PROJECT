package com.tourism.api.model;
public enum Role { TOURIST, TOUR_GUIDE, ADMIN }
