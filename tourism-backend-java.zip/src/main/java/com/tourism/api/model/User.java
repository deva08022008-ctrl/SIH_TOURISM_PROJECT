package com.tourism.api.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity @Table(name="users")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class User {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false, unique=true, length=180)
    private String email;

    @Column(nullable=false)
    private String passwordHash;

    @Column(nullable=false, length=120)
    private String fullName;

    @Enumerated(EnumType.STRING) @Column(nullable=false, length=30)
    private Role role = Role.TOURIST;

    @Column(nullable=false)
    private boolean enabled = true;

    @Column(nullable=false, updatable=false)
    private Instant createdAt;

    @PrePersist void prePersist(){ createdAt = Instant.now(); }
}
