package com.tourism.api.model;
public enum PaymentProvider { STRIPE, RAZORPAY, PAYPAL, MOCK }
