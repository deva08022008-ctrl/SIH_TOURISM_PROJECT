package com.tourism.api.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Table(name="destinations")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Destination {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false, length=180) private String name;
    @Column(nullable=false, length=120) private String city;
    @Column(nullable=false, length=120) private String country;
    @Column(nullable=false, length=60) private String category;
    @Column(nullable=false, columnDefinition="TEXT") private String description;
    private BigDecimal price;
    private boolean available = true;
    private Double latitude;
    private Double longitude;
    private String imageUrl;

    @OneToMany(mappedBy="destination", cascade=CascadeType.ALL, orphanRemoval=true)
    @Builder.Default private List<Review> reviews = new ArrayList<>();
}
