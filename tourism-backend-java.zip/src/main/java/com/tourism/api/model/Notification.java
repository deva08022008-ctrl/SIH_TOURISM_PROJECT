package com.tourism.api.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity @Table(name="notifications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Notification {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch=FetchType.LAZY, optional=false) private User user;
    @Column(nullable=false, length=180) private String title;
    @Column(nullable=false, columnDefinition="text") private String message;
    @Column(nullable=false) private boolean readFlag = false;
    @Column(nullable=false) private Instant createdAt;
    @PrePersist void prePersist(){ if(createdAt==null) createdAt=Instant.now(); }
}
