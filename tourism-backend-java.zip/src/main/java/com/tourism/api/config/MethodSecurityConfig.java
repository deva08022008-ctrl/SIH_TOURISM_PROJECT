package com.tourism.api.config;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
@Configuration @EnableMethodSecurity
public class MethodSecurityConfig {}
