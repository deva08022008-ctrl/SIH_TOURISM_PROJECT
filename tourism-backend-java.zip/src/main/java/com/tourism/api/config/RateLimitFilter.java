package com.tourism.api.config;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class RateLimitFilter extends OncePerRequestFilter {
 private final int limit;
 private final ConcurrentHashMap<String, Window> windows=new ConcurrentHashMap<>();
 public RateLimitFilter(@Value("${app.rate-limit.requests-per-minute:120}") int limit){this.limit=limit;}
 @Override protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
   String ip=req.getRemoteAddr(); long minute=Instant.now().getEpochSecond()/60;
   Window w=windows.compute(ip,(k,v)->v==null||v.minute!=minute?new Window(minute):v);
   if(w.count.incrementAndGet()>limit){res.setStatus(429);res.setHeader("Retry-After","60");res.setContentType("application/json");res.getWriter().write("{\"error\":\"Too many requests\"}");return;}
   chain.doFilter(req,res);
 }
 private static class Window{long minute;AtomicInteger count=new AtomicInteger();Window(long m){minute=m;}}
}
