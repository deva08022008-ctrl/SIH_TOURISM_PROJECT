package com.tourism.api.config;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.slf4j.*;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

@Component
public class RequestLoggingFilter extends OncePerRequestFilter {
 private static final Logger log=LoggerFactory.getLogger(RequestLoggingFilter.class);
 @Override protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
   long start=System.currentTimeMillis(); chain.doFilter(req,res);
   log.info("{} {} -> {} ({} ms)",req.getMethod(),req.getRequestURI(),res.getStatus(),System.currentTimeMillis()-start);
 }
}
