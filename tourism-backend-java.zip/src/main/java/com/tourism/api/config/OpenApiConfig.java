package com.tourism.api.config;
import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class OpenApiConfig {
 @Bean OpenAPI tourismOpenAPI(){
   return new OpenAPI().info(new Info().title("Tourism API").version("1.0.0").description("Tourism booking, destinations, reviews, itineraries, payments and notifications API"))
     .components(new Components().addSecuritySchemes("bearerAuth",new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")));
 }
}
