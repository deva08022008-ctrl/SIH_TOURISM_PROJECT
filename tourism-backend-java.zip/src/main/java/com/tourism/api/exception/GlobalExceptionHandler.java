package com.tourism.api.exception;

import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ApiException.class)
    ResponseEntity<?> api(ApiException e){return body(e.status,e.getMessage());}
    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<?> validation(MethodArgumentNotValidException e){
        String msg=e.getBindingResult().getFieldErrors().stream().map(x->x.getField()+": "+x.getDefaultMessage()).collect(Collectors.joining(", "));
        return body(HttpStatus.BAD_REQUEST,msg);
    }
    @ExceptionHandler(Exception.class)
    ResponseEntity<?> generic(Exception e){ return body(HttpStatus.INTERNAL_SERVER_ERROR,"An unexpected error occurred"); }
    private ResponseEntity<?> body(HttpStatus s,String m){
        return ResponseEntity.status(s).body(new ErrorResponse(Instant.now(),s.value(),s.getReasonPhrase(),m));
    }
    record ErrorResponse(Instant timestamp,int status,String error,String message){}
}
