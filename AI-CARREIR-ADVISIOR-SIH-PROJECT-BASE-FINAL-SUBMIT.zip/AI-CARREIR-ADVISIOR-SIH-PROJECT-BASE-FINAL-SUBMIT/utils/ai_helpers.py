import json
from utils.career_data import CAREER_DATA, COLLEGE_DATA, SKILL_DATA, JOB_DATA
from datetime import datetime
import time
from google import genai
import os
from utils.language_detection import detect_language, extract_language_request, get_language_name
from config import Config

# Initialize Gemini client
GEMINI_API_KEY = Config.GEMINI_API_KEY

def setup_gemini():
    """Configure the Gemini AI client with Flash model"""
    try:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            print("❌ ERROR: Gemini API key not found. Please set GEMINI_API_KEY in your environment.")
            return None
            
        # Initialize the new Gemini client
        client = genai.Client(api_key=api_key)
        
        # Test the connection with a simple request
        try:
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents='Hello'
            )
            print("✅ Gemini API connection successful")
        except Exception as e:
            print(f"⚠️ Gemini connection test failed: {e}")
            return None
        
        return client
        
    except Exception as e:
        print(f"❌ Error setting up Gemini: {e}")
        return None

def get_gemini_response(user_message, user_profile=None):
    """Get response from Gemini based on user message and profile"""
    max_retries = 2
    retry_delay = 1  # seconds
    
    for attempt in range(max_retries):
        try:
            client = setup_gemini()
            if not client:
                return "⚠️ I'm having trouble connecting to the AI service. Please check your API key and try again later."
            
            # Career guidance context
            context = """You are CareerGuide, a friendly and expert AI career advisor chatbot. 
            Provide helpful, professional advice about careers, education, skills development, and job opportunities.

            Guidelines:
            1. Be conversational but professional
            2. Keep answers concise (2–4 paragraphs)
            3. Focus on practical, actionable advice
            4. Suggest courses, certifications, or platforms where possible
            5. Be supportive and encouraging
            6. If unsure, suggest alternative resources
            """
            
            # Add user profile details
            if user_profile:
                profile_context = f"""
                USER PROFILE (Use this to personalize your response):
                - Name: {getattr(user_profile, 'full_name', 'Not provided')}
                - Age: {getattr(user_profile, 'age', 'Not specified')}
                - Education Level: {getattr(user_profile, 'education_level', 'Not specified')}
                - Current Status: {getattr(user_profile, 'current_status', 'Not specified')}
                - Interests: {getattr(user_profile, 'interests', 'Not specified')}
                - Skills: {getattr(user_profile, 'skills', 'Not specified')}
                - Academic Performance: {getattr(user_profile, 'academic_score', 'Not specified')}
                - Career Goals: {getattr(user_profile, 'career_goals', 'Not specified')}
                - Preferred Location: {getattr(user_profile, 'preferred_location', 'Flexible')}
                - Education Budget: {getattr(user_profile, 'budget_for_education', 'Not specified')}
                """
                context += profile_context
            
            # Final prompt
            prompt = f"""{context}

            Current Conversation:
            User: {user_message}
            
            CareerGuide:"""
            
            # Generate response using the new client
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt,
                config={
                    'temperature': 0.7,
                    'top_p': 0.8,
                    'top_k': 40,
                    'max_output_tokens': 2048,
                }
            )
            
            return response.text.strip()
            
        except Exception as e:
            print(f"⚠️ Attempt {attempt + 1} failed: {e}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
            else:
                return "⚠️ I'm experiencing technical difficulties. Please try again later or ask a different question."

def get_career_recommendations(profile):
    """Get AI-powered career recommendations using Gemini"""
    try:
        client = setup_gemini()
        if not client:
            return []  # Return empty list if Gemini not available
            
        prompt = f"""Based on this user profile, suggest 3-5 suitable career paths with details:

        Profile:
        - Age: {profile.age or 'Not specified'}
        - Education: {profile.education_level or 'Not specified'}
        - Status: {profile.current_status or 'Not specified'}
        - Interests: {profile.interests or 'Not specified'}
        - Skills: {profile.skills or 'Not specified'}
        - Academic Score: {profile.academic_score or 'Not specified'}
        - Career Goals: {profile.career_goals or 'Not specified'}
        
        For each career suggestion, provide:
        1. Career title
        2. Brief description
        3. Required skills/education
        4. Growth potential
        5. Average salary range
        6. Why it matches this profile
        
        Format the response as a clear list without markdown."""
        
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
            config={
                'temperature': 0.7,
                'max_output_tokens': 2048,
            }
        )
        return response.text
        
    except Exception as e:
        print(f"Error getting AI career recommendations: {e}")
        return "I'm unable to generate personalized career recommendations right now. Please try again later."

def generate_career_roadmap(profile, career_goal):
    """Generate a personalized career roadmap using Gemini"""
    try:
        client = setup_gemini()
        if not client:
            return {"short_term": [], "medium_term": [], "long_term": []}
            
        prompt = f"""Create a step-by-step career roadmap for this user to achieve: {career_goal}

        User Profile:
        - Current Education: {profile.education_level or 'Not specified'}
        - Current Status: {profile.current_status or 'Not specified'}
        - Skills: {profile.skills or 'Not specified'}
        - Interests: {profile.interests or 'Not specified'}
        
        Provide the roadmap in three timeframes:
        1. Short-term (0-6 months): Immediate actions
        2. Medium-term (6-18 months): Skill development and preparation
        3. Long-term (18+ months): Career advancement steps
        
        Make each step practical and actionable."""
        
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
            config={
                'temperature': 0.7,
                'max_output_tokens': 2048,
            }
        )
        return response.text
        
    except Exception as e:
        print(f"Error generating career roadmap: {e}")
        return "I'm unable to generate a career roadmap right now. Please try again later."

def get_college_recommendations(profile):
    recommendations = []
    
    for college in COLLEGE_DATA:
        score = 0
        
        # Match based on academic score
        if profile.academic_score and college['min_score'] <= float(profile.academic_score) <= college['max_score']:
            score += 4
        
        # Match based on preferred location
        if profile.preferred_location and profile.preferred_location.lower() in college['location'].lower():
            score += 3
            
        # Match based on budget
        if profile.budget_for_education and college['fees'] <= float(profile.budget_for_education):
            score += 3
            
        if score > 0:
            recommendations.append({
                'name': college['name'],
                'location': college['location'],
                'courses': college['courses'],
                'fees': college['fees'],
                'rating': college['rating'],
                'match_score': min(score, 10)
            })
    
    recommendations.sort(key=lambda x: x['match_score'], reverse=True)
    return recommendations[:5]

def get_skill_recommendations(profile):
    recommendations = []
    
    for skill in SKILL_DATA:
        score = 0
        
        # Match based on career goals
        if profile.career_goals and any(goal.lower() in skill['related_careers'] for goal in profile.career_goals.split(',')):
            score += 4
            
        # Match based on interests
        if profile.interests and any(interest.lower() in skill['category'].lower() for interest in profile.interests.split(',')):
            score += 3
            
        if score > 0:
            recommendations.append({
                'name': skill['name'],
                'description': skill['description'],
                'platform': skill['platform'],
                'link': skill['link'],
                'level': skill['level'],
                'match_score': min(score, 10)
            })
    
    recommendations.sort(key=lambda x: x['match_score'], reverse=True)
    return recommendations[:5]

def get_job_recommendations(profile):
    recommendations = []
    
    for job in JOB_DATA:
        score = 0
        
        # Match based on skills
        if profile.skills:
            user_skills = [skill.strip().lower() for skill in profile.skills.split(',')]
            job_skills = [skill.strip().lower() for skill in job['required_skills']]
            matched_skills = set(user_skills) & set(job_skills)
            score += len(matched_skills) * 2
        
        # Match based on education
        if profile.education_level and profile.education_level.lower() in job['education'].lower():
            score += 3
            
        # Match based on location
        if profile.preferred_location and profile.preferred_location.lower() in job['location'].lower():
            score += 2
            
        if score > 0:
            recommendations.append({
                'title': job['title'],
                'company': job['company'],
                'location': job['location'],
                'skills': job['required_skills'],
                'salary': job['salary'],
                'link': job['link'],
                'match_score': min(score, 10)
            })
    
    recommendations.sort(key=lambda x: x['match_score'], reverse=True)
    return recommendations[:5]

# Note: There's a duplicate function definition below - keeping the non-AI version
def generate_career_roadmap_basic(profile):
    # This would be more sophisticated in a real application
    roadmap = {
        'short_term': [
            'Complete your current education level',
            'Identify 2-3 key skills to develop based on your interests',
            'Explore internship opportunities in your field of interest'
        ],
        'medium_term': [
            'Gain practical experience through projects or freelance work',
            'Build a professional network in your desired industry',
            'Consider certifications to enhance your credentials'
        ],
        'long_term': [
            'Secure a position in your chosen career path',
            'Continue learning and advancing in your field',
            'Consider mentorship opportunities to guide others'
        ]
    }
    
    return roadmap

def analyze_career_risk(career_goal):
    # Simplified risk analysis - real implementation would use more data
    risk_data = {
        'automation_risk': 'Medium',
        'job_growth': '7% (Faster than average)',
        'salary_trend': 'Increasing',
        'competition': 'Moderate to High',
        'recommendations': [
            'Focus on developing unique specializations',
            'Build a strong professional network',
            'Continuously update your skills'
        ]
    }
    
    return risk_data

def calculate_education_cost(profile):
    # Simplified cost calculation
    if not profile.budget_for_education:
        return {'error': 'No budget information provided'}
    
    budget = float(profile.budget_for_education)
    
    # Sample education costs
    education_options = [
        {'type': 'Online Certifications', 'cost': 5000, 'duration': '3-6 months'},
        {'type': 'Diploma Courses', 'cost': 50000, 'duration': '1-2 years'},
        {'type': 'Undergraduate Degree', 'cost': 300000, 'duration': '3-4 years'},
        {'type': 'Postgraduate Degree', 'cost': 200000, 'duration': '1-2 years'}
    ]
    
    affordable_options = [option for option in education_options if option['cost'] <= budget]
    
    return {
        'budget': budget,
        'affordable_options': affordable_options,
        'savings_required': max(0, min(option['cost'] for option in education_options if option['cost'] > budget) - budget) if any(option['cost'] > budget for option in education_options) else 0
    }