from gtts import gTTS
import pyttsx3
import os
from datetime import datetime
import threading
from utils.language_detection import detect_language

class VoiceSynthesizer:
    def __init__(self):
        self.online_mode = True
        self.offline_engine = None
        self.initialize_offline_engine()
    
    def initialize_offline_engine(self):
        try:
            self.offline_engine = pyttsx3.init()
            voices = self.offline_engine.getProperty('voices')
            if voices:
                self.offline_engine.setProperty('voice', voices[0].id)
            self.offline_engine.setProperty('rate', 150)
            self.offline_engine.setProperty('volume', 0.9)
        except Exception as e:
            print(f"Failed to initialize offline TTS engine: {e}")
            self.offline_engine = None
    
    def set_mode(self, online=True):
        self.online_mode = online
    
    def text_to_speech(self, text, lang='auto'):
        if self.online_mode:
            return self._online_tts(text, lang)
        else:
            return self._offline_tts(text)
    
    def _online_tts(self, text, lang='auto'):
        try:
            # Auto-detect language if not specified
            if lang == 'auto':
                lang = detect_language(text)
            
            # Map language codes to gTTS supported codes
            lang_map = {
                'en': 'en',    # English
                'hi': 'hi',    # Hindi
                'ta': 'ta',    # Tamil
                'te': 'te',    # Telugu
                'kn': 'kn',    # Kannada
                'ml': 'ml',    # Malayalam
                'bn': 'bn',    # Bengali
                'mr': 'mr',    # Marathi
                'gu': 'gu',    # Gujarati
                'pa': 'pa',    # Punjabi
            }
            
            tts_lang = lang_map.get(lang, 'en')
            
            # Create audio directory if it doesn't exist
            audio_dir = os.path.join('static', 'audio')
            if not os.path.exists(audio_dir):
                os.makedirs(audio_dir)
            
            # Generate filename with timestamp and language code
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"response_{lang}_{timestamp}.mp3"
            filepath = os.path.join(audio_dir, filename)
            
            # Generate speech using gTTS with specified language
            tts = gTTS(text=text, lang=tts_lang, slow=False)
            tts.save(filepath)
            
            return f"/static/audio/{filename}"
        except Exception as e:
            print(f"Error in online text-to-speech: {e}")
            # Fall back to offline if online fails
            return self._offline_tts(text)
    
    def _offline_tts(self, text):
        try:
            if not self.offline_engine:
                self.initialize_offline_engine()
                if not self.offline_engine:
                    return None
            
            # Create audio directory if it doesn't exist
            audio_dir = os.path.join('static', 'audio')
            if not os.path.exists(audio_dir):
                os.makedirs(audio_dir)
            
            # Generate filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"response_offline_{timestamp}.wav"
            filepath = os.path.join(audio_dir, filename)
            
            # Save to file using offline engine (English only)
            self.offline_engine.save_to_file(text, filepath)
            self.offline_engine.runAndWait()
            
            return f"/static/audio/{filename}"
        except Exception as e:
            print(f"Error in offline text-to-speech: {e}")
            return None

# Create a global instance
voice_synthesizer = VoiceSynthesizer()

# For backward compatibility
def text_to_speech(text, lang='auto'):
    return voice_synthesizer.text_to_speech(text, lang)