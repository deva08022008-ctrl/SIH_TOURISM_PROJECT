import re
from langdetect import detect, DetectorFactory
from langdetect.lang_detect_exception import LangDetectException

# For consistent results
DetectorFactory.seed = 0

# Language code mapping
LANGUAGE_CODES = {
    'en': 'English',
    'hi': 'Hindi',
    'ta': 'Tamil',
    'te': 'Telugu',
    'kn': 'Kannada',
    'ml': 'Malayalam',
    'bn': 'Bengali',
    'mr': 'Marathi',
    'gu': 'Gujarati',
    'pa': 'Punjabi'
}

def detect_language(text):
    """
    Detect the language of the given text
    Returns language code (e.g., 'en', 'hi', 'ta')
    """
    try:
        # Check if text is mostly English characters (common case)
        if is_mostly_english(text):
            return 'en'
        
        # Use langdetect for other languages
        lang_code = detect(text)
        
        # Map to supported languages or default to English
        return lang_code if lang_code in LANGUAGE_CODES else 'en'
        
    except (LangDetectException, Exception):
        return 'en'  # Default to English on error

def is_mostly_english(text):
    """
    Check if text contains mostly English characters
    """
    if not text.strip():
        return True
        
    # Count non-ASCII characters
    non_ascii_count = sum(1 for char in text if ord(char) > 127)
    
    # If less than 20% characters are non-ASCII, consider it English
    return (non_ascii_count / len(text)) < 0.2

def extract_language_request(text):
    """
    Check if user explicitly requests response in a specific language
    Returns (language_code, cleaned_text) or (None, original_text)
    """
    text_lower = text.lower()
    
    # Patterns to detect language requests
    patterns = {
        'hi': [r'answer in hindi', r'in hindi', r'hindi(?: me| mein)?'],
        'ta': [r'answer in tamil', r'in tamil', r'tamil(?: la| il)?'],
        'te': [r'answer in telugu', r'in telugu', r'telugu(?: lo)?'],
        'kn': [r'answer in kannada', r'in kannada', r'kannada(?: alli)?'],
        'ml': [r'answer in malayalam', r'in malayalam', r'malayalam(?: il)?'],
        'bn': [r'answer in bengali', r'in bengali', r'bengali(?: te)?'],
        'mr': [r'answer in marathi', r'in marathi', r'marathi(?: tumhi)?'],
        'gu': [r'answer in gujarati', r'in gujarati', r'gujarati(?: ma)?'],
        'pa': [r'answer in punjabi', r'in punjabi', r'punjabi(?: vich)?']
    }
    
    for lang_code, lang_patterns in patterns.items():
        for pattern in lang_patterns:
            if re.search(pattern, text_lower):
                # Remove the language request from the text
                cleaned_text = re.sub(pattern, '', text_lower, flags=re.IGNORECASE).strip()
                return lang_code, cleaned_text if cleaned_text else text
    
    return None, text

def get_language_name(lang_code):
    """
    Get language name from code
    """
    return LANGUAGE_CODES.get(lang_code, 'English')