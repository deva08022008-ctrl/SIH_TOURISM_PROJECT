# Sample data - in a real application, this would come from a database or API

CAREER_DATA = [
    {
        'name': 'Software Developer',
        'description': 'Design and develop software applications',
        'interests': ['technology', 'programming', 'problem-solving'],
        'skills': ['programming', 'algorithms', 'data structures'],
        'required_education': 'Bachelor\'s degree',
        'growth': '22% (Much faster than average)',
        'salary': '$110,000'
    },
    {
        'name': 'Data Scientist',
        'description': 'Analyze and interpret complex data',
        'interests': ['data', 'statistics', 'analysis'],
        'skills': ['python', 'machine learning', 'statistics'],
        'required_education': 'Master\'s degree',
        'growth': '31% (Much faster than average)',
        'salary': '$125,000'
    },
    {
        'name': 'Digital Marketer',
        'description': 'Promote products and services through digital channels',
        'interests': ['marketing', 'social media', 'creativity'],
        'skills': ['SEO', 'content creation', 'analytics'],
        'required_education': 'Bachelor\'s degree',
        'growth': '10% (Faster than average)',
        'salary': '$65,000'
    }
]

COLLEGE_DATA = [
    {
        'name': 'Tech University',
        'location': 'Bangalore, India',
        'courses': ['Computer Science', 'Data Science', 'AI'],
        'fees': 200000,
        'min_score': 75,
        'max_score': 100,
        'rating': 4.5
    },
    {
        'name': 'Business Institute',
        'location': 'Mumbai, India',
        'courses': ['MBA', 'Marketing', 'Finance'],
        'fees': 150000,
        'min_score': 65,
        'max_score': 100,
        'rating': 4.2
    }
]

SKILL_DATA = [
    {
        'name': 'Python Programming',
        'description': 'Learn the fundamentals of Python programming',
        'platform': 'Coursera',
        'link': 'https://www.coursera.org/learn/python',
        'level': 'Beginner',
        'category': 'programming',
        'related_careers': ['Software Developer', 'Data Scientist']
    },
    {
        'name': 'Digital Marketing Fundamentals',
        'description': 'Learn the basics of digital marketing',
        'platform': 'Udemy',
        'link': 'https://www.udemy.com/digital-marketing',
        'level': 'Beginner',
        'category': 'marketing',
        'related_careers': ['Digital Marketer', 'Marketing Manager']
    }
]

JOB_DATA = [
    {
        'title': 'Junior Software Developer',
        'company': 'Tech Solutions Inc.',
        'location': 'Bangalore, India',
        'required_skills': ['Python', 'JavaScript', 'SQL'],
        'education': 'Bachelor\'s degree',
        'salary': '₹800,000',
        'link': 'https://example.com/job/123'
    },
    {
        'title': 'Marketing Intern',
        'company': 'Digital Agency',
        'location': 'Mumbai, India',
        'required_skills': ['SEO', 'Content Writing', 'Social Media'],
        'education': 'Bachelor\'s degree',
        'salary': '₹300,000',
        'link': 'https://example.com/job/456'
    }
]