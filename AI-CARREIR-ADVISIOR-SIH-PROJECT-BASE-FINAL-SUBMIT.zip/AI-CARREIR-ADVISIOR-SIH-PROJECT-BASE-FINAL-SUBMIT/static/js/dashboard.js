// Dashboard functionality
document.addEventListener('DOMContentLoaded', function() {
    // Chat functionality
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const chatMessages = document.getElementById('chat-messages');
    
    if (chatForm) {
        chatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            sendMessage();
        });
    }
    
    function sendMessage() {
        const message = chatInput.value.trim();
        if (!message) return;
        
        // Add user message to chat
        addMessage(message, 'user');
        chatInput.value = '';
        
         // Get voice settings
        const voiceEnabled = document.getElementById('voice-toggle') ? 
                         document.getElementById('voice-toggle').checked : true;

        // Send message to server
        fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
            message: message,
            voice: voiceEnabled
            })

        })
        .then(response => response.json())
        .then(data => {
            // Add bot response to chat
            addMessage(data.response, 'bot');
            
            // Play audio if available
            if (data.audio) {
                playAudio(data.audio);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            addMessage('Sorry, I encountered an error. Please try again.', 'bot');
        });
    }
    
    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${sender}-message`);
        messageDiv.textContent = text;
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    function playAudio(audioUrl) {
        const audio = new Audio(audioUrl);
        audio.play();
    }
    
    // Initialize charts or other dashboard elements
    initDashboardCharts();
});

function initDashboardCharts() {
    // This would initialize any charts for the dashboard
    // For example, using Chart.js
    console.log('Initializing dashboard charts...');
}