// Combined voice recognition and chat functionality
document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const chatMessages = document.getElementById('chat-messages');
    const voiceButton = document.getElementById('voice-button');
    const sendButton = document.getElementById('send-button');
    const typingIndicator = document.getElementById('typing-indicator');
    const robot = document.querySelector('.robot');
    const voiceToggle = document.getElementById('voice-toggle');
    const onlineModeToggle = document.getElementById('online-mode-toggle');
    
    // Variables
    let recognition;
    let isListening = false;
    
    // Initialize voice recognition if available
    function initVoiceRecognition() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'en-US';
            
            recognition.onstart = function() {
                isListening = true;
                updateVoiceUI();
                if (voiceButton) voiceButton.classList.add('listening');
            };
            
            recognition.onresult = function(event) {
                const transcript = event.results[0][0].transcript;
                if (chatInput) chatInput.value = transcript;
                // Auto-send after voice input
                sendMessage();
            };
            
            recognition.onerror = function(event) {
                console.error('Speech recognition error', event.error);
                isListening = false;
                updateVoiceUI();
                if (voiceButton) voiceButton.classList.remove('listening');
            };
            
            recognition.onend = function() {
                isListening = false;
                updateVoiceUI();
                if (voiceButton) voiceButton.classList.remove('listening');
            };
        } else {
            console.warn('Speech recognition not supported in this browser.');
            if (voiceButton) voiceButton.style.display = 'none';
            if (voiceToggle) voiceToggle.disabled = true;
        }
    }
    
    // Update voice UI elements
    function updateVoiceUI() {
        const button = document.getElementById('voice-toggle');
        if (button) {
            if (isListening) {
                button.innerHTML = '🛑 Stop Listening';
                button.classList.add('listening');
            } else {
                button.innerHTML = '🎤 Start Voice';
                button.classList.remove('listening');
            }
        }
    }
    
    // Toggle voice listening
    function toggleListening() {
        if (!recognition) {
            initVoiceRecognition();
        }
        
        if (isListening) {
            recognition.stop();
        } else {
            recognition.start();
        }
    }
    
    // Add message to chat
    function addMessage(text, sender) {
        if (!chatMessages) return;
        
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${sender}-message`);
        messageDiv.textContent = text;
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Show typing indicator
    function showTyping() {
        if (typingIndicator) {
            typingIndicator.style.display = 'block';
            if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }
    
    // Hide typing indicator
    function hideTyping() {
        if (typingIndicator) {
            typingIndicator.style.display = 'none';
        }
    }
    
    // Animate robot speaking
    function animateRobotSpeaking(isSpeaking) {
        if (robot) {
            if (isSpeaking) {
                robot.classList.add('speaking');
            } else {
                robot.classList.remove('speaking');
            }
        }
    }
    
    // Play audio response
    function playAudio(audioUrl) {
        if (!audioUrl) return;
        
        const audio = new Audio(audioUrl);
        audio.play();
        
        // Animate robot while audio is playing
        animateRobotSpeaking(true);
        audio.onended = function() {
            animateRobotSpeaking(false);
        };
        
        audio.onerror = function() {
            animateRobotSpeaking(false);
            console.error('Error playing audio');
        };
    }
    
    // Send message to server
    function sendMessage() {
        if (!chatInput) return;
        
        const message = chatInput.value.trim();
        if (!message) return;
        
        // Add user message to chat
        addMessage(message, 'user');
        chatInput.value = '';
        
        // Show typing indicator
        showTyping();
        
        // Get voice settings
        const voiceEnabled = voiceToggle ? voiceToggle.checked : true;
        
        // Send message to server
        fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                message: message,
                voice: voiceEnabled,
                mobile: true  // Indicate this is a mobile-style request
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Hide typing indicator
            hideTyping();
            
            // Add bot response to chat
            if (data.response) {
                addMessage(data.response, 'bot');
            } else {
                addMessage('I apologize, but I did not receive a valid response.', 'bot');
            }
            
            // Play audio if available
            if (data.audio) {
                playAudio(data.audio);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            hideTyping();
            addMessage('Sorry, I encountered an error. Please try again.', 'bot');
        });
    }
    
    // Set up event listeners
    function setupEventListeners() {
        // Send button
        if (sendButton) {
            sendButton.addEventListener('click', sendMessage);
        }
        
        // Chat input enter key
        if (chatInput) {
            chatInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });
        }
        
        // Voice button
        if (voiceButton) {
            voiceButton.addEventListener('click', toggleListening);
        }
        
        // Voice toggle checkbox
        if (voiceToggle) {
            // Load saved settings
            const voiceEnabled = localStorage.getItem('voiceEnabled') !== 'false';
            voiceToggle.checked = voiceEnabled;
            
            voiceToggle.addEventListener('change', function() {
                localStorage.setItem('voiceEnabled', this.checked);
            });
        }
        
        // Online mode toggle checkbox
        if (onlineModeToggle) {
            // Load saved settings
            const onlineMode = localStorage.getItem('onlineMode') !== 'false';
            onlineModeToggle.checked = onlineMode;
            
            onlineModeToggle.addEventListener('change', function() {
                localStorage.setItem('onlineMode', this.checked);
                
                // Update server setting
                fetch('/set_voice_mode', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ online_mode: this.checked })
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Voice mode set to:', data.mode);
                })
                .catch(error => {
                    console.error('Error setting voice mode:', error);
                });
            });
        }
        
        // Chat form submission
        if (chatForm) {
            chatForm.addEventListener('submit', function(e) {
                e.preventDefault();
                sendMessage();
            });
        }
    }
    
    // Initialize the application
    function init() {
        setupEventListeners();
        initVoiceRecognition();
        
        // Focus on chat input when page loads
        if (chatInput) {
            setTimeout(() => {
                chatInput.focus();
            }, 500);
        }
    }
    
    // Start the application
    init();
});