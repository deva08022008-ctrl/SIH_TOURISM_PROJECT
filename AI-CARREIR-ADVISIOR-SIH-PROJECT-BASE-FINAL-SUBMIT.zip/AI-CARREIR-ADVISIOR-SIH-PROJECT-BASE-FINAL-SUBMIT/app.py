from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models import db, User, UserProfile, ChatHistory
from config import Config
from utils.ai_helpers import get_career_recommendations, get_college_recommendations, get_skill_recommendations, get_job_recommendations, generate_career_roadmap, analyze_career_risk, calculate_education_cost
from utils.voice_synthesis import text_to_speech
import json
from utils.ai_helpers import get_gemini_response
from utils.language_detection import detect_language, extract_language_request, get_language_name
from utils.voice_synthesis import voice_synthesizer
from google import genai

# Add safe_float function to handle conversion safely
def safe_float(value, default=0.0):
    """
    Safely convert a value to float, returning default if conversion fails
    """
    if value is None or value == '':
        return default
    try:
        return float(value)
    except (ValueError, TypeError):
        return default

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    # FIXED: Changed from User.query.get() to db.session.get()
    return db.session.get(User, int(user_id))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('dashboard'))
        
        return render_template('login.html', error='Invalid username or password')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(username=username).first():
            return render_template('signup.html', error='Username already exists')
        
        if User.query.filter_by(email=email).first():
            return render_template('signup.html', error='Email already exists')
        
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        login_user(user)
        return redirect(url_for('profile'))
    
    return render_template('signup.html')

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        profile_data = {
            'full_name': request.form.get('full_name'),
            'age': (request.form.get('age')),
            'education_level': request.form.get('education_level'),
            'current_status': request.form.get('current_status'),
            'interests': request.form.get('interests'),
            'skills': request.form.get('skills'),
            'academic_score': safe_float(request.form.get('academic_score')),
            'career_goals': request.form.get('career_goals'),
            'preferred_location': request.form.get('preferred_location'),
            'budget_for_education': safe_float(request.form.get('budget_for_education')),
            'preferred_language': request.form.get('preferred_language', 'en')
        }
        
        profile = UserProfile.query.filter_by(user_id=current_user.id).first()
        
        if profile:
            for key, value in profile_data.items():
                setattr(profile, key, value)
        else:
            profile = UserProfile(user_id=current_user.id, **profile_data)
            db.session.add(profile)
        
        db.session.commit()
        return redirect(url_for('dashboard'))
    
    profile = UserProfile.query.filter_by(user_id=current_user.id).first()
    return render_template('profile.html', profile=profile)

@app.route('/dashboard')
@login_required
def dashboard():
    profile = UserProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        return redirect(url_for('profile'))
    
    return render_template('dashboard.html', profile=profile)

@app.route('/chat', methods=['GET', 'POST'])
@login_required
def chat():
    if request.method == 'POST':
        # Check if it's a JSON request (API call) or form submission
        if request.is_json:
            message = request.json.get('message')
            use_voice = request.json.get('voice', True)
            is_mobile = request.json.get('mobile', False)
        else:
            message = request.form.get('message')
            use_voice = request.form.get('voice', 'true').lower() == 'true'
            is_mobile = request.form.get('mobile', 'false').lower() == 'true'
        
        # Get user profile for context
        profile = UserProfile.query.filter_by(user_id=current_user.id).first()
        
        # Get response from Gemini AI
        response = get_gemini_response(message, profile)
        
        # Detect language for voice response
        response_lang = detect_language(response)
        
        # Save to chat history
        chat = ChatHistory(user_id=current_user.id, message=message, response=response)
        db.session.add(chat)
        db.session.commit()
        
        # Generate audio response if requested
        audio_file = None
        if use_voice:
            audio_file = voice_synthesizer.text_to_speech(response, response_lang)
        
        # Return JSON response for API calls/mobile requests
        if request.is_json or is_mobile:
            return jsonify({
                'response': response, 
                'audio': audio_file,
                'language': response_lang
            })
        
        # For regular web requests, render the template
        return render_template('chat.html', response=response, audio_file=audio_file)
    
    # GET request - show chat history
    chat_history = ChatHistory.query.filter_by(user_id=current_user.id).order_by(ChatHistory.timestamp.desc()).limit(10).all()
    return render_template('chat.html', chat_history=reversed(chat_history))

@app.route('/recommendations')
@login_required
def recommendations():
    profile = UserProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        return redirect(url_for('profile'))
    
    career_recs = get_career_recommendations(profile)
    college_recs = get_college_recommendations(profile)
    skill_recs = get_skill_recommendations(profile)
    job_recs = get_job_recommendations(profile)
    roadmap = generate_career_roadmap(profile)
    risk_analysis = analyze_career_risk(profile.career_goals if profile.career_goals else "Software Engineer")
    cost_analysis = calculate_education_cost(profile)
    
    return render_template('recommendations.html', 
                          career_recs=career_recs, 
                          college_recs=college_recs,
                          skill_recs=skill_recs,
                          job_recs=job_recs,
                          roadmap=roadmap,
                          risk_analysis=risk_analysis,
                          cost_analysis=cost_analysis)

@app.route('/set_voice_mode', methods=['POST'])
@login_required
def set_voice_mode():
    online_mode = request.json.get('online_mode', True)
    voice_synthesizer.set_mode(online_mode)
    return jsonify({'status': 'success', 'mode': 'online' if online_mode else 'offline'})

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

def generate_chat_response(message, user):
    # This is a simplified version - you would integrate with a proper AI service
    profile = UserProfile.query.filter_by(user_id=user.id).first()
    
    # Basic response logic - in a real app, you'd use an AI API
    message_lower = message.lower()
    
    if any(word in message_lower for word in ['hello', 'hi', 'hey', 'hola']):
        return f"Hello {user.username}! How can I help with your career questions today?"
    
    elif any(word in message_lower for word in ['career', 'job', 'employment']):
        return "I can help you explore career options based on your skills and interests. Would you like me to suggest some career paths?"
    
    elif any(word in message_lower for word in ['college', 'university', 'education']):
        return "Based on your profile, I can recommend colleges and courses that match your academic background and interests."
    
    elif any(word in message_lower for word in ['skill', 'learn', 'course']):
        return "I can suggest skills to develop and online courses from platforms like Coursera, Udemy, and NPTEL to help you advance your career."
    
    elif any(word in message_lower for word in ['scholarship', 'financial', 'funding']):
        return "I can provide information about scholarships and financial aid options for your education. Would you like to explore these options?"
    
    else:
        return "I'm here to help with your career development. You can ask me about career options, colleges, skills development, job opportunities, or scholarships."

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)