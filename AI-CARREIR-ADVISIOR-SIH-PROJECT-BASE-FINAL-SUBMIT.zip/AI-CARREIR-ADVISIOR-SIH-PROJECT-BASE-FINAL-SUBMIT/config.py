import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-here'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///database.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # FIXED: Correctly get API key from environment variable
    GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY') or 'AIzaSyCvwq-c2i8krKZdz8M5OFgF0q-qKXAzyTM'